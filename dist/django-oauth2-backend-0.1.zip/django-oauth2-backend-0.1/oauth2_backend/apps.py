from django.apps import AppConfig


class Oauth2BackendConfig(AppConfig):
    name = 'oauth2_backend'
    verbose_name = "Django OAuth2 Backend"
